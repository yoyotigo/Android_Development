package com.example.tiago.groupproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ItemsAdapter extends ArrayAdapter<Item> {

    private ArrayList<Item> dataSet;
    Context context;

    public ItemsAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Item> objects) {
        super(context, resource, objects);
        this.context = context;
        this.dataSet = objects;
    }


    //FIND ELEMENT BASED ON POSITION IN DATASET, AND SETS VIEW UP WITH INFORMATION
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null)
        {
            LayoutInflater inf = LayoutInflater.from(context);
            convertView = inf.inflate(R.layout.row_layout, parent, false);
        }

        //SETUP CONTENT FOR VIEW
        TextView name = convertView.findViewById(R.id.txtName);
        TextView address = convertView.findViewById(R.id.txtAddress);
        TextView description = convertView.findViewById(R.id.txtDescription);
        TextView tags = convertView.findViewById(R.id.txtTags);

        Item i = dataSet.get(position);
        name.setText(i.getName());
        address.setText(i.getAddress());
        description.setText(i.getDescription());
        tags.setText(i.getTags());

        return convertView;
    }
}
