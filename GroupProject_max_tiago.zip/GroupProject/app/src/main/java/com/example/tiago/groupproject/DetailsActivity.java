package com.example.tiago.groupproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class DetailsActivity extends AppCompatActivity {

    private int pos;
    //RATE RESTAURANT BUTTON
    RatingBar ratingbar1;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Intent i = getIntent();
        String name = i.getStringExtra("name");
        final String address = i.getStringExtra("address");
        String description = i.getStringExtra("description");
        String tags = i.getStringExtra("tags");
        pos = i.getIntExtra("position", -1);        //-1 means not set

        EditText ename = findViewById(R.id.editName);
        EditText eaddress = findViewById(R.id.editAddress);
        EditText edescription = findViewById(R.id.editDescription);
        EditText etags = findViewById(R.id.editTags);
        ename.setText(name);
        eaddress.setText(address);
        edescription.setText(description);
        etags.setText(tags);

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = getIntent();
                EditText ename = findViewById(R.id.editName);
                EditText eaddress = findViewById(R.id.editAddress);
                EditText edescription = findViewById(R.id.editDescription);
                EditText etags = findViewById(R.id.editTags);

                String name = ename.getText().toString();
                String address = eaddress.getText().toString();
                String description = edescription.getText().toString();
                String tags = etags.getText().toString();

                i.putExtra("name", name);
                i.putExtra("address", address);
                i.putExtra("description", description);
                i.putExtra("tags", tags);
                i.putExtra("position", pos);

                setResult(RESULT_OK, i);
                finish();
            }
        });

        ///AUTO FILLS MAP WITH ADDRESS FORMATTED FOR URI
        findViewById(R.id.btnMap).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressRemoveSpaces;
                addressRemoveSpaces = address.replace(" ","+");
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo: 0,0?q=" +addressRemoveSpaces)); // Fills map with request


                startActivity(i);
            }
        });
        //
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        addListenerOnButton();



    }

    public void addListenerOnButton()
    {
        ratingbar1 = (RatingBar) findViewById(R.id.rating1);
        button = (Button) findViewById(R.id.btnRate);

        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View arg0)
            {
                String rating = String.valueOf(ratingbar1.getRating());
                Toast.makeText(getApplicationContext(), rating, Toast.LENGTH_LONG).show();
            }
        });
    }
}
