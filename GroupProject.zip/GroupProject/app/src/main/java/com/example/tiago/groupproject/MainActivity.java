package com.example.tiago.groupproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Item> items;
    private ItemsAdapter itemsAdapter;
    private ListView lvItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvItems = findViewById(R.id.itemList);
        items = new ArrayList<>();
        items.add(new Item("Mcdonalds", "108 queen st", "come get a junior chicken", "fast food"));
        items.add(new Item("Pizza Pizza", "9 moms st", "wonderful pizza made by mom", "pizza"));

        itemsAdapter = new ItemsAdapter(this, R.layout.row_layout, items);
        lvItems.setAdapter(itemsAdapter);

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //ADD NEW ITEM TO LIST
                EditText et = findViewById(R.id.editItem);
                String text = et.getText().toString();
                if (!text.isEmpty()) {
                    itemsAdapter.add(new Item(text, "default address", "default desc", "default tag"));
                    et.setText("");
                }
            }
        });

        Button btn1 = findViewById(R.id.btnabout);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,aboutmembers.class);
                startActivity(i);
            }
        });


        //INTERACTION WITH LIST ITEMS (LONG CLICK TO DELETE)
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                final int pos = position;

                new AlertDialog.Builder(view.getContext()).setTitle("Warning!")
                        .setMessage("Do you want to remove this item?")
                        .setNegativeButton(android.R.string.no, null)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                items.remove(pos);
                                itemsAdapter.notifyDataSetChanged();
                            }
                        }).show();
                return true;

            }
        });

        //ADD NEW LISTENER TO LIST
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(view.getContext(), DetailsActivity.class);
                i.putExtra("position", position);
                i.putExtra("name", items.get(position).getName());
                i.putExtra("address", items.get(position).getAddress());
                i.putExtra("description", items.get(position).getDescription());
                i.putExtra("tags", items.get(position).getTags());
                startActivityForResult(i, EDIT_ITEM);

            }
        });
    }


    //DEFINE OUR CALL OF EDIT ITEM
    public static final int EDIT_ITEM = 1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode==EDIT_ITEM)
        {
            if(resultCode==RESULT_OK)
            {

                int pos = data.getIntExtra("position", -1);
                if(pos!=-1)
                {
                    String name = data.getStringExtra("name");
                    String address = data.getStringExtra("address");
                    String description = data.getStringExtra("description");
                    String tags = data.getStringExtra("tags");
                    Item item = items.get(pos);
                    item.setName(name);
                    items.set(pos, item);
                    itemsAdapter.notifyDataSetChanged();

                }

            }
        }


    }
}
